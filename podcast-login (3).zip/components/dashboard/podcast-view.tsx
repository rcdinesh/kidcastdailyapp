"use client"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Headphones, ArrowLeft, Play, Pause, Volume2, Loader2, Trash } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { createClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import type { Database } from "@/lib/database.types"
import { generateAudio } from "@/lib/actions/generate-audio"

type Podcast = Database["public"]["Tables"]["podcasts"]["Row"]

interface PodcastViewProps {
  podcast: Podcast
  userId: string
}

export default function PodcastView({ podcast, userId }: PodcastViewProps) {
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const router = useRouter()
  const supabase = createClient()
  const { toast } = useToast()

  useEffect(() => {
    if (podcast.audio_url && audioRef.current) {
      const audio = audioRef.current

      const handleLoadedMetadata = () => {
        setDuration(audio.duration || 0)
      }

      const handleTimeUpdate = () => {
        setCurrentTime(audio.currentTime || 0)
      }

      const handleEnded = () => {
        setIsPlaying(false)
      }

      const handleError = (e: ErrorEvent) => {
        console.error("Audio playback error:", e)
        setError("Failed to load audio. Please try regenerating.")
      }

      audio.addEventListener("loadedmetadata", handleLoadedMetadata)
      audio.addEventListener("timeupdate", handleTimeUpdate)
      audio.addEventListener("ended", handleEnded)
      audio.addEventListener("error", handleError as EventListener)

      return () => {
        audio.removeEventListener("loadedmetadata", handleLoadedMetadata)
        audio.removeEventListener("timeupdate", handleTimeUpdate)
        audio.removeEventListener("ended", handleEnded)
        audio.removeEventListener("error", handleError as EventListener)
      }
    }
  }, [podcast.audio_url])

  const handleGenerateAudio = async () => {
    setIsGeneratingAudio(true)
    setError(null)

    try {
      const audioUrl = await generateAudio(podcast.script)

      const { error } = await supabase
        .from("podcasts")
        .update({
          audio_url: audioUrl,
          tts_provider: "google-tts",
        })
        .eq("id", podcast.id)

      if (error) throw error

      toast({
        title: "Audio generated",
        description: "Your podcast audio has been created successfully",
      })

      // Update the podcast object locally
      podcast.audio_url = audioUrl
      podcast.tts_provider = "google-tts"

      router.refresh()
    } catch (error: any) {
      console.error("Error generating audio:", error)
      setError(error.message || "Failed to generate audio")
      toast({
        title: "Generation failed",
        description: error.message || "Failed to generate audio. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGeneratingAudio(false)
    }
  }

  const handleDeletePodcast = async () => {
    try {
      // If there's an audio file, delete it from storage first
      if (podcast.audio_url) {
        const audioPath = new URL(podcast.audio_url).pathname.split("/").pop()
        if (audioPath && audioPath.includes(userId)) {
          await supabase.storage.from("podcast_audio").remove([`${userId}/${audioPath}`])
        }
      }

      // Delete the podcast record
      const { error } = await supabase.from("podcasts").delete().eq("id", podcast.id)

      if (error) throw error

      toast({
        title: "Podcast deleted",
        description: "Your podcast has been deleted successfully",
      })

      router.push("/dashboard")
      router.refresh()
    } catch (error: any) {
      console.error("Error deleting podcast:", error)
      toast({
        title: "Delete failed",
        description: error.message || "Failed to delete podcast. Please try again.",
        variant: "destructive",
      })
    }
  }

  const togglePlayPause = () => {
    if (!audioRef.current) return

    if (isPlaying) {
      audioRef.current.pause()
    } else {
      audioRef.current.play().catch((err) => {
        console.error("Playback error:", err)
        setError("Failed to play audio. Please try again.")
      })
    }

    setIsPlaying(!isPlaying)
  }

  const handleSliderChange = (value: number[]) => {
    if (!audioRef.current) return

    const newTime = value[0]
    audioRef.current.currentTime = newTime
    setCurrentTime(newTime)
  }

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="flex justify-between items-center mb-8">
        <div className="flex items-center space-x-3">
          <div className="rounded-full p-2 bg-purple-100">
            <Headphones className="h-6 w-6 text-purple-500" />
          </div>
          <div className="flex flex-col items-start">
            <h1 className="text-white font-extrabold">Kidcast Daily</h1>
            <p className="text-white/90 -mt-1">Podcast Generator</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="text-red-600 hover:text-red-700 hover:bg-red-50 bg-transparent"
              >
                <Trash className="h-4 w-4 mr-1" />
                Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete this podcast and any associated audio files. This action cannot be
                  undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeletePodcast} className="bg-red-600 hover:bg-red-700">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          <Button variant="ghost" asChild>
            <Link href="/dashboard">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
        </div>
      </header>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>{podcast.title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-medium mb-2">Topic</h3>
            <p>{podcast.topic}</p>
          </div>

          <div>
            <h3 className="font-medium mb-2">Script</h3>
            <div className="prose prose-sm max-w-none border rounded-md p-4 bg-gray-50">
              {podcast.script.split("\n").map((line, i) => (
                <p key={i}>{line}</p>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-medium mb-2">Audio</h3>
            {podcast.audio_url ? (
              <div className="space-y-4">
                <audio ref={audioRef} src={podcast.audio_url} className="hidden" />

                {error ? (
                  <div className="p-3 bg-red-100 border border-red-300 text-red-700 rounded-md text-sm mb-4">
                    {error}
                    <Button
                      onClick={handleGenerateAudio}
                      disabled={isGeneratingAudio}
                      size="sm"
                      className="ml-4 bg-red-600 hover:bg-red-700"
                    >
                      Regenerate Audio
                    </Button>
                  </div>
                ) : null}

                <div className="flex items-center space-x-4">
                  <Button
                    onClick={togglePlayPause}
                    size="sm"
                    variant="outline"
                    className="h-10 w-10 rounded-full p-0 flex items-center justify-center bg-transparent"
                  >
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 ml-0.5" />}
                  </Button>

                  <div className="flex-1 space-y-1">
                    <Slider
                      value={[currentTime]}
                      max={duration || 100}
                      step={0.1}
                      onValueChange={handleSliderChange}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>{formatTime(currentTime)}</span>
                      <span>{formatTime(duration)}</span>
                    </div>
                  </div>

                  <Volume2 className="h-4 w-4 text-gray-500" />
                </div>

                <p className="text-xs text-gray-500">Generated using {podcast.tts_provider || "text-to-speech"}</p>
              </div>
            ) : (
              <div className="text-center py-8 border rounded-md">
                <Headphones className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                <p className="text-gray-500 mb-4">No audio generated yet</p>
                <Button
                  onClick={handleGenerateAudio}
                  disabled={isGeneratingAudio}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  {isGeneratingAudio ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Generating Audio...
                    </>
                  ) : (
                    <>
                      <Volume2 className="h-4 w-4 mr-2" />
                      Generate Audio
                    </>
                  )}
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
