import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { Headphones, Play, FileText } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Database } from "@/lib/database.types"

type Podcast = Database["public"]["Tables"]["podcasts"]["Row"]

interface PodcastCardProps {
  podcast: Podcast
}

export default function PodcastCard({ podcast }: PodcastCardProps) {
  const hasAudio = !!podcast.audio_url

  return (
    <Card className="overflow-hidden">
      <div className="h-3 bg-purple-500" />
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-semibold text-lg line-clamp-1">{podcast.title}</h3>
            <p className="text-sm text-gray-500 mt-1">Topic: {podcast.topic}</p>
          </div>
          <div className="rounded-full p-2 bg-purple-100">
            <Headphones className="h-5 w-5 text-purple-500" />
          </div>
        </div>

        <p className="text-sm text-gray-600 mt-4 line-clamp-3">{podcast.script.substring(0, 150)}...</p>
      </CardContent>

      <CardFooter className="flex justify-between border-t pt-4 pb-4">
        <div className="text-xs text-gray-500">
          {formatDistanceToNow(new Date(podcast.created_at), { addSuffix: true })}
        </div>
        <div className="flex space-x-2">
          <Button asChild size="sm" variant="outline">
            <Link href={`/dashboard/podcast/${podcast.id}`}>
              <FileText className="h-4 w-4 mr-1" />
              View
            </Link>
          </Button>
          {hasAudio && (
            <Button asChild size="sm" className="bg-purple-600 hover:bg-purple-700">
              <Link href={`/dashboard/podcast/${podcast.id}#play`}>
                <Play className="h-4 w-4 mr-1" />
                Play
              </Link>
            </Button>
          )}
        </div>
      </CardFooter>
    </Card>
  )
}
