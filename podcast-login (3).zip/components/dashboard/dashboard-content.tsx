"use client"

import { useState } from "react"
import Link from "next/link"
import type { User } from "@supabase/supabase-js"
import { Headphones, Plus, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import type { Database } from "@/lib/database.types"
import PodcastCard from "@/components/dashboard/podcast-card"
import { useToast } from "@/hooks/use-toast"

type Podcast = Database["public"]["Tables"]["podcasts"]["Row"]

interface DashboardContentProps {
  initialPodcasts: Podcast[]
  user: User
}

export default function DashboardContent({ initialPodcasts, user }: DashboardContentProps) {
  const [podcasts, setPodcasts] = useState<Podcast[]>(initialPodcasts)
  const router = useRouter()
  const supabase = createClient()
  const { toast } = useToast()

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push("/auth/login")
    router.refresh()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="flex justify-between items-center mb-8">
        <div className="flex items-center space-x-3">
          <div className="rounded-full p-2 bg-purple-100">
            <Headphones className="h-6 w-6 text-purple-500" />
          </div>
          <div className="flex flex-col items-start">
            <h1 className="text-2xl font-extrabold text-white">Kidcast Daily</h1>
            <p className="text-sm font-medium text-white/90 -mt-1">Podcast Generator</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <span className="text-sm text-gray-600">{user.email}</span>
          <Button variant="outline" size="sm" onClick={handleSignOut}>
            <LogOut className="h-4 w-4 mr-2" />
            Sign out
          </Button>
        </div>
      </header>

      <div className="mb-8">
        <Button asChild className="bg-purple-600 hover:bg-purple-700">
          <Link href="/dashboard/create">
            <Plus className="h-4 w-4 mr-2" />
            Create New Podcast
          </Link>
        </Button>
      </div>

      <h2 className="text-xl font-semibold mb-4">Your Podcasts</h2>

      {podcasts.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <Headphones className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No podcasts yet</h3>
          <p className="text-gray-500 mb-4">Create your first AI-generated podcast for kids!</p>
          <Button asChild className="bg-purple-600 hover:bg-purple-700">
            <Link href="/dashboard/create">
              <Plus className="h-4 w-4 mr-2" />
              Create New Podcast
            </Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {podcasts.map((podcast) => (
            <PodcastCard key={podcast.id} podcast={podcast} />
          ))}
        </div>
      )}
    </div>
  )
}
