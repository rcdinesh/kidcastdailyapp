"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Headphones, ArrowLeft, Wand2, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { createClient } from "@/lib/supabase/client"
import { useToast } from "@/hooks/use-toast"
import { generatePodcastScript } from "@/lib/actions/generate-script"

const DEFAULT_PROMPT = `Create a fun and educational podcast script for kids aged 7-10 about {topic}. 

The podcast should:
1. Start with an engaging introduction that captures attention
2. Include 3-5 interesting recent news events about {topic}
3. Explain concepts in simple language in long details so that children can understand
4. Include a fun activity or quiz related to {topic}
5. End with a brief conclusion that summarizes what was learned

The script should be around 2500-3000 words and take about 10-15 minutes to read aloud.`

const PREDEFINED_TOPICS = [
  { id: "sonic", name: "Sonic the Hedgehog" },
  { id: "soccer", name: "Soccer" },
  { id: "pokemon", name: "Pokémon" },
  { id: "basketball", name: "Basketball" },
  { id: "custom", name: "Custom Topic" },
]

interface CreatePodcastFormProps {
  userId: string
}

export default function CreatePodcastForm({ userId }: CreatePodcastFormProps) {
  const [title, setTitle] = useState("")
  const [selectedTopic, setSelectedTopic] = useState("sonic")
  const [customTopic, setCustomTopic] = useState("")
  const [prompt, setPrompt] = useState(DEFAULT_PROMPT)
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedScript, setGeneratedScript] = useState("")
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()
  const { toast } = useToast()

  const handleTopicChange = (value: string) => {
    setSelectedTopic(value)
  }

  const getCurrentTopic = () => {
    if (selectedTopic === "custom") {
      return customTopic
    }
    return PREDEFINED_TOPICS.find((topic) => topic.id === selectedTopic)?.name || ""
  }

  const handleGenerateScript = async () => {
    const topic = getCurrentTopic()
    setError(null)

    if (!topic) {
      toast({
        title: "Topic required",
        description: "Please select a topic or enter a custom one",
        variant: "destructive",
      })
      return
    }

    if (!title) {
      toast({
        title: "Title required",
        description: "Please enter a title for your podcast",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)

    try {
      const finalPrompt = prompt.replace(/\{topic\}/g, topic)
      const script = await generatePodcastScript(finalPrompt)
      setGeneratedScript(script)

      toast({
        title: "Script generated",
        description: "Your podcast script has been created successfully",
      })
    } catch (error: any) {
      console.error("Error generating script:", error)
      setError(error.message || "Failed to generate podcast script. Please try again.")
      toast({
        title: "Generation failed",
        description: error.message || "Failed to generate podcast script. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleSavePodcast = async () => {
    if (!generatedScript) {
      toast({
        title: "No script",
        description: "Please generate a script first",
        variant: "destructive",
      })
      return
    }

    try {
      const topic = getCurrentTopic()

      const { data, error } = await supabase
        .from("podcasts")
        .insert({
          user_id: userId,
          title,
          topic,
          prompt: prompt.replace(/\{topic\}/g, topic),
          script: generatedScript,
        })
        .select()

      if (error) throw error

      toast({
        title: "Podcast saved",
        description: "Your podcast has been saved successfully",
      })

      router.push("/")
      router.refresh()
    } catch (error: any) {
      console.error("Error saving podcast:", error)
      toast({
        title: "Save failed",
        description: error.message || "Failed to save podcast. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <header className="flex justify-between items-center mb-8">
        <div className="flex items-center space-x-3">
          <div className="rounded-full p-2 bg-purple-100">
            <Headphones className="h-6 w-6 text-purple-500" />
          </div>
          <h1 className="text-2xl font-bold">PodBuilder Jr.</h1>
        </div>
        <Button variant="ghost" asChild>
          <Link href="/">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Link>
        </Button>
      </header>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Create New Podcast</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="title">Podcast Title</Label>
            <Input
              id="title"
              placeholder="Enter a title for your podcast"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div className="space-y-3">
            <Label>Select Topic</Label>
            <RadioGroup value={selectedTopic} onValueChange={handleTopicChange} className="grid grid-cols-2 gap-2">
              {PREDEFINED_TOPICS.map((topic) => (
                <div key={topic.id} className="flex items-center space-x-2">
                  <RadioGroupItem value={topic.id} id={`topic-${topic.id}`} />
                  <Label htmlFor={`topic-${topic.id}`}>{topic.name}</Label>
                </div>
              ))}
            </RadioGroup>

            {selectedTopic === "custom" && (
              <div className="mt-3">
                <Label htmlFor="customTopic">Custom Topic</Label>
                <Input
                  id="customTopic"
                  placeholder="Enter your custom topic"
                  value={customTopic}
                  onChange={(e) => setCustomTopic(e.target.value)}
                />
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="prompt">Custom Prompt (Advanced)</Label>
            <Textarea
              id="prompt"
              placeholder="Enter your custom prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={5}
              className="font-mono text-sm"
            />
            <p className="text-xs text-gray-500">Use {"{topic}"} as a placeholder for your selected topic.</p>
          </div>

          <Button
            onClick={handleGenerateScript}
            disabled={isGenerating}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            {isGenerating ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                <span>Generating script with Perplexity AI...</span>
              </div>
            ) : (
              <>
                <Wand2 className="h-4 w-4 mr-2" />
                Generate Podcast Script
              </>
            )}
          </Button>

          {generatedScript && (
            <div className="space-y-4 mt-6">
              <div className="border rounded-md p-4 bg-gray-50">
                <h3 className="font-medium mb-2">Generated Script</h3>
                <div className="prose prose-sm max-w-none">
                  {generatedScript.split("\n").map((line, i) => (
                    <p key={i}>{line}</p>
                  ))}
                </div>
              </div>

              <div className="flex justify-end">
                <Button onClick={handleSavePodcast}>Save Podcast</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
