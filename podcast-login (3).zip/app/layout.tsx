import type React from "react"
import "@/app/globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Kidcast Daily",
  description: "Your podcast creation platform",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="bg-animation" id="bgAnimation">
          {/* Render a few static particles for the animation */}
          <div className="particle w-2 h-2 left-[10%] top-[20%] animate-[float_15s_infinite_ease-in-out] animation-delay-[0s] animation-duration-[10s]"></div>
          <div className="particle w-3 h-3 left-[30%] top-[50%] animate-[float_18s_infinite_ease-in-out] animation-delay-[3s] animation-duration-[12s]"></div>
          <div className="particle w-4 h-4 left-[60%] top-[10%] animate-[float_12s_infinite_ease-in-out] animation-delay-[6s] animation-duration-[8s]"></div>
          <div className="particle w-2 h-2 left-[80%] top-[70%] animate-[float_16s_infinite_ease-in-out] animation-delay-[9s] animation-duration-[11s]"></div>
          <div className="particle w-5 h-5 left-[40%] top-[80%] animate-[float_20s_infinite_ease-in-out] animation-delay-[12s] animation-duration-[14s]"></div>
        </div>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}
