import PodcastCreator from "@/components/podcast/podcast-creator"

export default function HomePage() {
  // Using a fixed guest user ID for all users
  const guestUserId = "guest-user-123"

  return (
    <div
      className="flex items-center justify-center py-20 bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: 'url("/images/kidcast-background-v2.png")' }}
    >
      <PodcastCreator userId={guestUserId} />
    </div>
  )
}
