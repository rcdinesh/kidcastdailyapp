import Link from "next/link"
import { Headphones } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function CreatePodcastPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center space-y-6">
        <div className="flex justify-center">
          <div className="rounded-full p-4 bg-purple-100">
            <Headphones className="h-12 w-12 text-purple-500" />
          </div>
        </div>
        <div className="flex flex-col items-center">
          <h1 className="text-3xl font-extrabold text-white">Kidcast Daily</h1>
          <p className="text-lg font-medium text-white/90 -mt-1">Podcast Generator</p>
        </div>
        <p className="text-gray-600 max-w-md mx-auto">
          The dashboard functionality has been replaced with a guest experience. Please use the main page to create
          podcasts.
        </p>
        <Button asChild className="bg-purple-600 hover:bg-purple-700">
          <Link href="/">Return to Home</Link>
        </Button>
      </div>
    </div>
  )
}
