import { notFound, redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import PodcastView from "@/components/dashboard/podcast-view"

export default async function PodcastPage({ params }: { params: { id: string } }) {
  const supabase = createClient()

  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/auth/login")
  }

  const { data: podcast } = await supabase
    .from("podcasts")
    .select("*")
    .eq("id", params.id)
    .eq("user_id", session.user.id)
    .single()

  if (!podcast) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <PodcastView podcast={podcast} userId={session.user.id} />
    </div>
  )
}
