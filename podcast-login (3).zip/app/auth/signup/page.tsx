"use client"

import type React from "react"

import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Headphones } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function SignupPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      console.log("Attempting to sign up with:", email)
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          },
        },
      })

      if (error) {
        console.error("Signup error:", error)
        setError(error.message)
        return
      }

      console.log("Signup successful:", data)
      setSuccess(true)

      // If auto-confirmation is enabled, redirect to dashboard
      if (data.session) {
        router.push("/dashboard")
        router.refresh()
      }
    } catch (error) {
      console.error("Unexpected signup error:", error)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-100 to-blue-200">
        <Card className="w-full max-w-md shadow-lg">
          <CardHeader className="flex flex-col items-center space-y-2 pt-8">
            <div className="rounded-full p-3 bg-white">
              <Headphones className="h-8 w-8 text-purple-500" />
            </div>
            <div className="flex flex-col items-center">
              <h1 className="text-3xl font-extrabold text-center text-white">Kidcast Daily</h1>
              <p className="text-sm font-medium text-white/90">Podcast Generator</p>
            </div>
          </CardHeader>
          <CardContent className="space-y-6 pt-4 pb-8 text-center">
            <h2 className="text-xl font-medium">Account Created!</h2>
            <p className="text-gray-600">
              Please check your email for a confirmation link. Once confirmed, you can log in to your account.
            </p>
            <Button asChild className="mt-4">
              <Link href="/auth/login">Go to Login</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-100 to-blue-200">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="flex flex-col items-center space-y-2 pt-8">
          <div className="rounded-full p-3 bg-white">
            <Headphones className="h-8 w-8 text-purple-500" />
          </div>
          <div className="flex flex-col items-center">
            <h1 className="text-3xl font-extrabold text-center text-white">Kidcast Daily</h1>
            <p className="text-sm font-medium text-white/90">Podcast Generator</p>
          </div>
          <p className="text-sm text-gray-500">Create your account</p>
        </CardHeader>
        <CardContent className="space-y-6 pt-4 pb-8">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSignup} className="space-y-6">
            <div className="space-y-2">
              <label htmlFor="fullName" className="text-sm text-gray-600">
                Full Name
              </label>
              <Input
                id="fullName"
                type="text"
                placeholder="Your full name"
                className="h-12"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="email" className="text-sm text-gray-600">
                Email address
              </label>
              <Input
                id="email"
                type="email"
                placeholder="Your email address"
                className="h-12"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="password" className="text-sm text-gray-600">
                Password
              </label>
              <Input
                id="password"
                type="password"
                placeholder="Create a password"
                className="h-12"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
              />
            </div>
            <Button type="submit" className="w-full h-12 bg-emerald-500 hover:bg-emerald-600" disabled={loading}>
              {loading ? "Creating account..." : "Create account"}
            </Button>
          </form>
          <div className="text-center pt-2">
            <span className="text-sm text-gray-500">Already have an account? </span>
            <Link href="/auth/login" className="text-sm text-gray-500 hover:text-gray-700">
              Sign in
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
