"use client"

import type React from "react"

import Link from "next/link"
import { useState } from "react"
import { Headphones } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function ResetPasswordPage() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const supabase = createClient()

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/auth/update-password`,
      })

      if (error) {
        console.error("Reset password error:", error)
        setError(error.message)
        return
      }

      setSuccess(true)
    } catch (error) {
      console.error("Unexpected reset password error:", error)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-100 to-blue-200">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="flex flex-col items-center space-y-2 pt-8">
          <div className="rounded-full p-3 bg-white">
            <Headphones className="h-8 w-8 text-purple-500" />
          </div>
          <div className="flex flex-col items-center">
            <h1 className="text-3xl font-extrabold text-center text-white">Kidcast Daily</h1>
            <p className="text-sm font-medium text-white/90 -mt-1">Podcast Generator</p>
          </div>
        </CardHeader>
        <CardContent className="space-y-6 pt-4 pb-8">
          {success ? (
            <div className="text-center space-y-4">
              <Alert className="bg-green-50 border-green-200 text-green-800">
                <AlertDescription>
                  If an account exists with that email, we've sent password reset instructions.
                </AlertDescription>
              </Alert>
              <p className="mt-4">
                Please check your email for a link to reset your password. If it doesn't appear within a few minutes,
                check your spam folder.
              </p>
              <Button asChild className="mt-4">
                <Link href="/auth/login">Return to Login</Link>
              </Button>
            </div>
          ) : (
            <>
              <h2 className="text-xl font-medium text-center">Reset your password</h2>
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              <form onSubmit={handleResetPassword} className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm text-gray-600">
                    Email address
                  </label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Your email address"
                    className="h-12"
                    required
                  />
                </div>
                <Button type="submit" className="w-full h-12 bg-emerald-500 hover:bg-emerald-600" disabled={loading}>
                  {loading ? "Sending..." : "Send reset link"}
                </Button>
                <div className="text-center">
                  <Link href="/auth/login" className="text-sm text-gray-500 hover:text-gray-700">
                    Back to sign in
                  </Link>
                </div>
              </form>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
