"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Headphones } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function UpdatePasswordPage() {
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [userEmail, setUserEmail] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const checkUser = async () => {
      const { data, error } = await supabase.auth.getUser()
      if (error || !data?.user) {
        console.error("Error getting user:", error)
        setError("Password reset link is invalid or has expired. Please request a new one.")
        return
      }
      setUserEmail(data.user.email)
    }

    checkUser()
  }, [supabase.auth])

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    if (password !== confirmPassword) {
      setError("Passwords don't match")
      setLoading(false)
      return
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters")
      setLoading(false)
      return
    }

    try {
      const { error } = await supabase.auth.updateUser({ password })

      if (error) {
        console.error("Update password error:", error)
        setError(error.message)
        return
      }

      // Password updated successfully
      router.push("/auth/login?reset=success")
    } catch (error) {
      console.error("Unexpected update password error:", error)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-100 to-blue-200">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="flex flex-col items-center space-y-2 pt-8">
          <div className="rounded-full p-3 bg-white">
            <Headphones className="h-8 w-8 text-purple-500" />
          </div>
          <div className="flex flex-col items-center">
            <h1 className="text-3xl font-extrabold text-center text-white">Kidcast Daily</h1>
            <p className="text-sm font-medium text-white/90 -mt-1">Podcast Generator</p>
          </div>
        </CardHeader>
        <CardContent className="space-y-6 pt-4 pb-8">
          <h2 className="text-xl font-medium text-center">Set new password</h2>
          {userEmail && <p className="text-center text-sm text-gray-600">For account: {userEmail}</p>}

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleUpdatePassword} className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="password" className="text-sm text-gray-600">
                New Password
              </label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="New password"
                className="h-12"
                required
                minLength={6}
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="confirmPassword" className="text-sm text-gray-600">
                Confirm Password
              </label>
              <Input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm new password"
                className="h-12"
                required
                minLength={6}
              />
            </div>
            <Button
              type="submit"
              className="w-full h-12 bg-emerald-500 hover:bg-emerald-600"
              disabled={loading || !userEmail}
            >
              {loading ? "Updating..." : "Update Password"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
