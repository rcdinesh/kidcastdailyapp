"use client"

import type React from "react"

import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Headphones } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      console.log("Attempting to sign in with:", email)
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        console.error("Login error:", error)
        setError(error.message)
        return
      }

      console.log("Login successful, redirecting to dashboard")
      router.push("/dashboard")
      router.refresh()
    } catch (error) {
      console.error("Unexpected login error:", error)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-100 to-blue-200">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="flex flex-col items-center space-y-2 pt-8">
          <div className="rounded-full p-3 bg-white">
            <Headphones className="h-8 w-8 text-purple-500" />
          </div>
          <div className="flex flex-col items-center">
            <h1 className="text-3xl font-extrabold text-center text-white">Kidcast Daily</h1>
            <p className="text-sm font-medium text-white/90 -mt-1">Podcast Generator</p>
          </div>
        </CardHeader>
        <CardContent className="space-y-6 pt-4 pb-8">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label htmlFor="email" className="text-sm text-gray-600">
                Email address
              </label>
              <Input
                id="email"
                type="email"
                placeholder="Your email address"
                className="h-12"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="password" className="text-sm text-gray-600">
                Your Password
              </label>
              <Input
                id="password"
                type="password"
                placeholder="Your password"
                className="h-12"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <Button type="submit" className="w-full h-12 bg-emerald-500 hover:bg-emerald-600" disabled={loading}>
              {loading ? "Signing in..." : "Sign in"}
            </Button>
          </form>
          <div className="text-center space-y-2 pt-2">
            <div>
              <Link href="/auth/reset-password" className="text-sm text-gray-500 hover:text-gray-700">
                Forgot your password?
              </Link>
            </div>
            <div>
              <span className="text-sm text-gray-500">Don't have an account? </span>
              <Link href="/auth/signup" className="text-sm text-gray-500 hover:text-gray-700">
                Sign up
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
