/**
 * Thoroughly cleans a script for direct text-to-speech readout
 * @param script The original script text
 * @returns Cleaned script text optimized for TTS
 */
export function cleanScript(script: string): string {
  if (!script) return ""

  // Remove content within square brackets (including the brackets)
  let cleanedScript = script.replace(/\[.*?\]/g, "")

  // Remove markdown symbols
  cleanedScript = cleanedScript.replace(/[#*_~`]/g, "")

  // Remove common section titles and meta-text
  const sectionPatterns = [
    /^introduction:?\s*/gim,
    /^intro:?\s*/gim,
    /^conclusion:?\s*/gim,
    /^segment\s+\d+:?\s*/gim,
    /^section\s+\d+:?\s*/gim,
    /^part\s+\d+:?\s*/gim,
    /^podcast\s+script:?\s*/gim,
    /^script:?\s*/gim,
    /^title:?\s*/gim,
    /^host:?\s*/gim,
    /^narrator:?\s*/gim,
    /^speaker:?\s*/gim,
    /^opening:?\s*/gim,
    /^closing:?\s*/gim,
    /^outro:?\s*/gim,
    /^summary:?\s*/gim,
    /^topic:?\s*/gim,
    /^welcome to the podcast\s*/gim,
    /^welcome to our podcast\s*/gim,
    /^thank you for listening\s*/gim,
    /^end of podcast\s*/gim,
  ]

  // Apply each pattern
  sectionPatterns.forEach((pattern) => {
    cleanedScript = cleanedScript.replace(pattern, "")
  })

  // Remove lines that are likely headers (short lines with colons or all caps)
  cleanedScript = cleanedScript
    .split("\n")
    .filter((line) => {
      const trimmedLine = line.trim()
      // Skip empty lines
      if (trimmedLine.length === 0) return false

      // Skip likely headers (short all-caps lines)
      if (trimmedLine.length < 30 && trimmedLine === trimmedLine.toUpperCase() && /^[A-Z\s]+$/.test(trimmedLine)) {
        return false
      }

      // Skip lines that are just ":" or just numbers
      if (/^[\d\s:]+$/.test(trimmedLine)) {
        return false
      }

      return true
    })
    .join("\n")

  // Remove any double spaces that might have been created
  cleanedScript = cleanedScript.replace(/\s+/g, " ")

  // Split by newlines, filter out empty lines, and join back
  cleanedScript = cleanedScript
    .split("\n")
    .filter((line) => line.trim().length > 0)
    .join("\n")

  // Remove any remaining common podcast intro/outro phrases
  const phrasePatterns = [
    /hello and welcome to our podcast\s*/gi,
    /welcome back to our podcast\s*/gi,
    /thanks for tuning in\s*/gi,
    /don't forget to subscribe\s*/gi,
    /if you enjoyed this podcast\s*/gi,
    /in today's episode\s*/gi,
    /in this episode\s*/gi,
  ]

  phrasePatterns.forEach((pattern) => {
    cleanedScript = cleanedScript.replace(pattern, "")
  })

  return cleanedScript
}
