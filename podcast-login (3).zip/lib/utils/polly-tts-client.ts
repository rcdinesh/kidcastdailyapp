import { createHash, createHmac } from "crypto" // Import Node.js crypto module

// AWS configuration
const AWS_REGION = "us-east-1"
const AWS_SERVICE = "polly"
const AWS_HOST = `${AWS_SERVICE}.${AWS_REGION}.amazonaws.com`

// Correct AWS v4 signature implementation using Node.js crypto
async function createAwsSignature(
  method: string,
  path: string,
  headers: Record<string, string>,
  body: string,
): Promise<Record<string, string>> {
  try {
    const accessKey = process.env.AWS_ACCESS_KEY_ID?.trim()
    const secretKey = process.env.AWS_SECRET_ACCESS_KEY?.trim()

    if (!accessKey || !secretKey) {
      throw new Error(
        "AWS credentials (AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY) are not set in environment variables.",
      )
    }

    const now = new Date()
    const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, "")
    const dateStamp = amzDate.substring(0, 8)

    // Calculate payload hash
    const payloadHash = createHash("sha256").update(body).digest("hex")

    // Create canonical headers (must be sorted)
    const canonicalHeaders = {
      "content-type": headers["content-type"] || "application/x-amz-json-1.0",
      host: AWS_HOST,
      "x-amz-content-sha256": payloadHash,
      "x-amz-date": amzDate,
    }

    const sortedHeaderKeys = Object.keys(canonicalHeaders).sort()
    const canonicalHeadersString = sortedHeaderKeys.map((key) => `${key}:${canonicalHeaders[key]}`).join("\n") + "\n"
    const signedHeaders = sortedHeaderKeys.join(";")

    // Create canonical request
    const canonicalRequest = [
      method,
      path,
      "", // query string
      canonicalHeadersString,
      signedHeaders,
      payloadHash,
    ].join("\n")

    // Create string to sign
    const algorithm = "AWS4-HMAC-SHA256"
    const credentialScope = `${dateStamp}/${AWS_REGION}/${AWS_SERVICE}/aws4_request`
    const canonicalRequestHash = createHash("sha256").update(canonicalRequest).digest("hex")
    const stringToSign = [algorithm, amzDate, credentialScope, canonicalRequestHash].join("\n")

    // Calculate signature using proper key derivation
    const kDate = createHmac("sha256", "AWS4" + secretKey)
      .update(dateStamp)
      .digest()
    const kRegion = createHmac("sha256", kDate).update(AWS_REGION).digest()
    const kService = createHmac("sha256", kRegion).update(AWS_SERVICE).digest()
    const kSigning = createHmac("sha256", kService).update("aws4_request").digest()

    const signature = createHmac("sha256", kSigning).update(stringToSign).digest("hex")

    // Create authorization header
    const authorizationHeader = `${algorithm} Credential=${accessKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`

    return {
      Authorization: authorizationHeader,
      "Content-Type": canonicalHeaders["content-type"],
      Host: canonicalHeaders.host,
      "X-Amz-Content-Sha256": canonicalHeaders["x-amz-content-sha256"],
      "X-Amz-Date": canonicalHeaders["x-amz-date"],
    }
  } catch (error) {
    console.error("Error in createAwsSignature:", error)
    throw error
  }
}

// Function to split text into chunks for long texts
function splitTextIntoChunks(text: string, maxLength = 2500): string[] {
  if (text.length <= maxLength) {
    return [text]
  }

  const chunks: string[] = []
  let currentChunk = ""

  // Split by sentences first
  const sentences = text.split(/([.!?]+\s+)/)

  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i] || ""
    const punctuation = sentences[i + 1] || ""
    const sentenceWithPunctuation = sentence + punctuation

    if ((currentChunk + sentenceWithPunctuation).length <= maxLength) {
      currentChunk += sentenceWithPunctuation
    } else {
      if (currentChunk.trim()) {
        chunks.push(currentChunk.trim())
      }

      // If the sentence itself is too long, split it by words
      if (sentenceWithPunctuation.length > maxLength) {
        const words = sentenceWithPunctuation.split(/(\s+)/)
        let wordChunk = ""

        for (const word of words) {
          if ((wordChunk + word).length <= maxLength) {
            wordChunk += word
          } else {
            if (wordChunk.trim()) {
              chunks.push(wordChunk.trim())
            }
            wordChunk = word
          }
        }

        if (wordChunk.trim()) {
          currentChunk = wordChunk
        } else {
          currentChunk = ""
        }
      } else {
        currentChunk = sentenceWithPunctuation
      }
    }
  }

  if (currentChunk.trim()) {
    chunks.push(currentChunk.trim())
  }

  return chunks.filter((chunk) => chunk.length > 0)
}

// Function to call Amazon Polly API with high-quality settings
async function callPollyApi(text: string, voice: any, outputFormat = "mp3", quality = "premium") {
  try {
    const method = "POST"
    const path = "/v1/speech"

    // Determine engine based on voice
    let engine = "standard"
    if (voice?.engine === "neural") {
      engine = "neural"
    } else if (voice?.engine === "generative") {
      engine = "generative"
    }

    // Always use MP3 format
    const pollyOutputFormat = "mp3"

    // Set sample rate based on quality for MP3
    let sampleRate = "24000" // Default to high quality 24kHz

    if (quality === "standard") {
      sampleRate = "16000" // Standard quality
    } else if (quality === "high") {
      sampleRate = "22050" // High quality
    } else if (quality === "premium") {
      sampleRate = "24000" // Premium quality - highest supported for MP3
    }

    const requestBody = {
      Text: text,
      VoiceId: voice?.name || "Danielle",
      OutputFormat: pollyOutputFormat,
      Engine: engine,
      SampleRate: sampleRate, // Explicitly set sample rate for quality
      ...(engine === "generative" && {
        TextType: text.includes("<speak>") ? "ssml" : "text",
        LanguageCode: voice?.languageCode || "en-US",
      }),
      // Add SSML support for better pronunciation and pacing
      ...(text.includes("<speak>") && { TextType: "ssml" }),
    }

    console.log(`Polly request: Engine=${engine}, SampleRate=${sampleRate}, Quality=${quality}`)

    const payload = JSON.stringify(requestBody)
    const headers = { "content-type": "application/x-amz-json-1.0" }

    // Sign the request
    const signedHeaders = await createAwsSignature(method, path, headers, payload)

    // Make request to Amazon Polly with timeout
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 30000) // 30 second timeout

    try {
      const response = await fetch(`https://${AWS_HOST}${path}`, {
        method,
        headers: signedHeaders,
        body: payload,
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        const errorText = await response.text()
        console.error("Polly API error (text):", errorText)
        throw new Error(`Polly API error: ${response.status} ${response.statusText} - ${errorText.substring(0, 500)}`)
      }

      // Return audio buffer with validation
      const audioBuffer = await response.arrayBuffer()
      const audioArray = new Uint8Array(audioBuffer)

      // Validate audio data
      if (audioArray.length === 0) {
        throw new Error("Received empty audio data from Amazon Polly")
      }

      // Basic MP3 format validation
      if (audioArray.length < 100) {
        throw new Error("Received invalid MP3 audio data")
      }

      console.log(`Received high-quality MP3 audio: ${audioArray.length} bytes at ${sampleRate}Hz`)

      return audioArray
    } catch (error) {
      clearTimeout(timeoutId)
      if (error.name === "AbortError") {
        throw new Error("Request to Amazon Polly timed out after 30 seconds")
      }
      throw error
    }
  } catch (error) {
    console.error("Error in callPollyApi:", error)
    throw error
  }
}

// Proper base64 encoding for binary data using Node.js Buffer
function arrayBufferToBase64(buffer: Uint8Array): string {
  try {
    return Buffer.from(buffer).toString("base64")
  } catch (error) {
    console.error("Error in arrayBufferToBase64:", error)
    throw error
  }
}

export async function synthesizeSpeechWithPolly(
  text: string,
  voice: { name: string; engine?: string; languageCode?: string },
  quality = "premium",
): Promise<{ audioContent: string; contentType: string }> {
  console.log("Amazon Polly high-quality text-to-speech utility called")

  try {
    if (!text) {
      throw new Error("Text is required for speech synthesis")
    }

    console.log(`Processing with quality: ${quality}`)

    // Handle long texts by chunking
    const textChunks = splitTextIntoChunks(text, 3000)
    console.log(`Processing ${textChunks.length} text chunks`)

    const audioBuffers: Uint8Array[] = []

    // Process each chunk
    for (let i = 0; i < textChunks.length; i++) {
      const chunk = textChunks[i]
      console.log(`Processing chunk ${i + 1}/${textChunks.length} (${chunk.length} characters)`)

      try {
        const audioBuffer = await callPollyApi(chunk, voice, "mp3", quality)
        audioBuffers.push(audioBuffer)

        // Add a small delay between requests to avoid rate limiting
        if (i < textChunks.length - 1) {
          await new Promise((resolve) => setTimeout(resolve, 100))
        }
      } catch (chunkError) {
        console.error(`Error processing chunk ${i + 1}:`, chunkError)
        throw new Error(
          `Failed to process text chunk ${i + 1}: ${chunkError instanceof Error ? chunkError.message : "Unknown error"}`,
        )
      }
    }

    // Combine audio buffers
    let combinedLength = 0
    for (const buffer of audioBuffers) {
      combinedLength += buffer.length
    }

    const combinedAudio = new Uint8Array(combinedLength)
    let offset = 0

    for (const buffer of audioBuffers) {
      combinedAudio.set(buffer, offset)
      offset += buffer.length
    }

    // Convert to base64 safely
    let audioBase64
    try {
      audioBase64 = arrayBufferToBase64(combinedAudio)
    } catch (base64Error) {
      console.error("Error converting audio to base64:", base64Error)
      throw new Error(
        `Failed to encode audio data: ${base64Error instanceof Error ? base64Error.message : "Unknown error"}`,
      )
    }

    if (!audioBase64 || audioBase64.length === 0) {
      throw new Error("Received empty audio content from Amazon Polly")
    }

    return {
      audioContent: audioBase64,
      contentType: "audio/mpeg",
    }
  } catch (error) {
    console.error("Unhandled error in Amazon Polly TTS utility:", error)
    throw error instanceof Error ? error : new Error("Failed to convert text to speech with Amazon Polly")
  }
}
